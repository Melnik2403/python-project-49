### Hexlet tests and linter status:
[![Actions Status](https://github.com/Melnik2403/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Melnik2403/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/5e6eefbcf4041a9fb1dd/maintainability)](https://codeclimate.com/github/Melnik2403/python-project-49/maintainability)
### Asciinema:
https://asciinema.org/a/LerYWrBAP6UEZ5z4ZZcdku5iw
