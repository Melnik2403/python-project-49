#!/usr/bin/env python3

from brain_games import cli


def main():
    cli.brain_calc(cli.welcome_user())


if __name__ == '__main__':
    main()
